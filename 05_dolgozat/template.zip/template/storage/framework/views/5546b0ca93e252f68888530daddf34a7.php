<?php $__env->startSection('content'); ?>
    OK
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\BG\13C_Laravel\03_jobs\resources\views/home.blade.php ENDPATH**/ ?>