<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title></title>
    <?php echo app('Illuminate\Foundation\Vite')('resources/css/app.css'); ?>
</head>

<body class="flex flex-col min-h-screen bg-gray-50">
    <header class="bg-white shadow">
        <div class="max-w-6xl mx-auto">
            <h1 class="text-2xl py-5">fejléc</h1>
        </div>
    </header>
    <main class="flex-1">
        <div class="max-w-6xl mx-auto">
            <?php echo $__env->yieldContent('content'); ?>
        </div>
    </main>
    <footer class="bg-white border-t border-gray-300 py-3">
        <div class="max-w-6xl mx-auto">
            <p class="text-sm italic">&copy;2026 - BG</p>
        </div>
    </footer>
</body>

</html>
<?php /**PATH D:\BG\13C_Laravel\03_jobs\resources\views/layouts/app.blade.php ENDPATH**/ ?>