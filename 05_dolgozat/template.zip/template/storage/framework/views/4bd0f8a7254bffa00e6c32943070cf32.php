<?php $__env->startSection('content'); ?>
    OK
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH E:\_2026\laravel\00_layout_template\resources\views/home.blade.php ENDPATH**/ ?>