@extends('layouts.app')

@section('content')
    OK
@endsection
